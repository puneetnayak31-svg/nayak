@echo off
where py >nul 2>nul
if %errorlevel%==0 (py -3 -m pip install --upgrade anthropic) else (python -m pip install --upgrade anthropic)
echo.
echo Done. Restart the CMS, then add your API key under Settings.
pause
