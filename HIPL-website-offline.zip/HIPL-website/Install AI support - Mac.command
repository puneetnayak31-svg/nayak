#!/bin/bash
python3 -m pip install --upgrade anthropic
echo
echo "Done. Restart the CMS, then add your API key under Settings."
read -r -p "Press Enter to close."
