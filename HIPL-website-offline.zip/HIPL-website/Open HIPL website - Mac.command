#!/bin/bash
open "$(cd "$(dirname "$0")" && pwd)/website/index.html"
