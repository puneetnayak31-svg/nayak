@echo off
cd /d "%~dp0source"
where py >nul 2>nul
if %errorlevel%==0 (py -3 cms\server.py) else (python cms\server.py)
echo.
echo The CMS has stopped. If you saw an error about Python, install Python 3 from python.org and tick "Add python.exe to PATH".
pause
