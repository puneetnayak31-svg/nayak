#!/bin/bash
cd "$(cd "$(dirname "$0")" && pwd)/source"
if command -v python3 >/dev/null; then python3 cms/server.py; else echo "Install Python 3 from python.org, then try again."; read -r; fi
